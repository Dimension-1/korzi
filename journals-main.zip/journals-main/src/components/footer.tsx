"use client";

import React from "react";
import Image from "next/image";

const HeroBanner = () => {
  return (
    <section
      className="relative bg-[var(--background)] text-[var(--foreground)] px-0 lg:px-12 rounded-t-[2rem] overflow-hidden h-[80vh] flex items-end pb-12"
      style={{
        backgroundImage: "url('/image.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="flex flex-col w-full lg:flex-row justify-center items-center gap-8 lg:gap-12 text-[var(--foreground)] text-lg font-light px-4 lg:px-0">
        <div className="absolute inset-0 bg-black/50"></div>
        <div className="flex flex-col lg:flex-row justify-center items-center gap-8 lg:gap-12 text-[var(--foreground)] text-lg font-light px-4 lg:px-0 py-2">
          <div className="flex flex-wrap justify-center gap-6">
            <a href="https://www.linkedin.com/in/shreyash-raj/" target="_blank" rel="noopener noreferrer" className="relative group transition-all duration-300 opacity-0 hidden lg:block hover:text-[var(--accent)]">
              /linkedin
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent)] transition-all duration-300 group-hover:w-full"></span>
            </a>
            <a href="https://www.linkedin.com/in/shreyash-raj/" target="_blank" rel="noopener noreferrer" className="relative group transition-all duration-300 hover:text-[var(--accent)]">
              /linkedin
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent)] transition-all duration-300 group-hover:w-full"></span>
            </a>
          </div>
          <h1 className="text-[3rem] lg:mx-5 z-5 justify-center flex px-4 md:text-[8rem] lg:text-[10rem] leading-none text-[var(--logo)]">
            <Image src="/logo-stacked.png" alt="Korzi Logo" width={400} height={100} className="md:mx-4 mx-1" />
          </h1>
          <div className="flex flex-wrap justify-center gap-6">
            <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" className="relative group transition-all duration-300 hover:text-[var(--accent)]">
              /instagram
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent)] transition-all duration-300 group-hover:w-full"></span>
            </a>
            <a href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer" className="relative group transition-all duration-300 hover:text-[var(--accent)]">
              /youtube
              <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-[var(--accent)] transition-all duration-300 group-hover:w-full"></span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
